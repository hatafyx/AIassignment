import torch
import torch.utils.data
from torch import nn
from torch.autograd import Variable
import numpy as np
import matplotlib.pyplot as plt
from pylab import rcParams

import pandas as pd

rcParams['figure.figsize'] = 15, 10


# read data from file and tranform them into vocabulary and frequency of words
# 16282 : size of vocabulary if take a single unique word as a unique token
def load_data(train_file,test_file):
    train_data = pd.read_csv(train_file, delimiter='\t', names=["text", "label"])
    test_data = pd.read_csv(test_file,delimiter='\t', names=["text","label"])
    train_pre = []
    test_pre = []
    for la in train_data["label"]:
        train_pre.append(la)
    for lb in test_data["label"]:
        test_pre.append(lb)
    # generate token dictionary
    token_index = {}
    for text in train_data["text"]:
        for word in text.strip().split():
            if word not in token_index:
                token_index[word] = len(token_index)+1
    train_one_hot_results = []
    test_one_hot_results = []
    lenvocab = len(token_index)
    for train_text in train_data["text"]:
        train_entry = np.zeros((lenvocab,), dtype=np.uint8)
        for word in train_text.strip().split():
            index = token_index.get(word)-1
            train_entry[index] = 1
        train_one_hot_results.append(train_entry)
    for test_text in test_data["text"]:
        test_entry = np.zeros((lenvocab,),dtype=np.uint8)
        for word in test_text.strip().split():
            try:
                index = token_index.get(word)-1
                test_entry[index] = 1
            except Exception:
                pass
        test_one_hot_results.append(test_entry)
    return train_one_hot_results, test_one_hot_results, train_pre, test_pre, token_index,lenvocab

# Model class
class Model(nn.Module):

    def __init__(self, lenvocab,input_dim, hidden1_dim, hidden2_dim, output_dim):
        super(Model, self).__init__()
        # attention weight randomly initialized vector
        self.weight_mat = Variable(torch.randn(50), requires_grad=True).to(device)

        self.embed_mat = Variable(torch.randn(lenvocab, 50), requires_grad=True).to(device)

        self.activation = nn.Softmax()

        self.hl1 = nn.Linear(input_dim, hidden1_dim)
        self.hl1d = nn.Dropout(0.2)
        self.hl1a = nn.ReLU()
        self.layer1 = [self.hl1, self.hl1d, self.hl1a]

        self.hl2 = nn.Linear(hidden1_dim, hidden2_dim)
        self.hl2d = nn.Dropout(0.2)
        self.hl2a = nn.ReLU()
        self.layer2 = [self.hl2, self.hl2d, self.hl2a]

        self.ol = nn.Linear(hidden2_dim, output_dim)

        self.layers = [self.layer1, self.layer2]

    def forward(self, x):
        out = torch.sum(self.weight_mat.mul(self.embed_mat),1,True)
        # generate attention distribution
        out = self.activation(out)
        # compute a weighted average of the word embeddings
        out = out.mul(self.embed_mat)

        out = torch.matmul(x.double(), out.double())

        for pa, d, a in self.layers:
            out = a(d(pa(out)))
        out = self.ol(out)
        return out

    def predict(self, text, vocabulary):
        """
        :param text: a list of words waited to be predicted
        :param vocabulary: vocabulary
        :return:
        """
        lenvocab = len(vocabulary)
        inputs = np.zeros((lenvocab,),dtype=np.uint8)
        activation = nn.Softmax()
        for word in text.strip().split():
            # if the word is in pre-trained embeddings
            try:
                index = vocabulary.get(word)-1
                inputs[index] = 1
            # if not , all-zero
            except Exception:
                pass
        output = self.forward(Variable([inputs]).to(device))
        dist = activation(output).data.numpy()
        if dist[0] >= dist[1]:
            return 1
        else:
            return 0



#Trainer for training
class Trainer():
    def __init__(self, model, data):

        self.model = model
        self.data = data

        self.train_loader = torch.utils.data.DataLoader(dataset=self.data, batch_size=32, shuffle=True)

    def train(self, lr, ne):

        criterion = nn.CrossEntropyLoss()
        activation = nn.Softmax()
        optimizer = torch.optim.SGD(self.model.parameters(), lr=lr, momentum=0.1)

        self.model.train()

        self.costs = []
        self.accuracy = []
        for e in range(ne):

            print('training epoch %d / %d ...' % (e + 1, ne))

            train_cost = 0
            train_accuracy = 0
            for batch_idx, (inputs, targets) in enumerate(self.train_loader):
                inputs = Variable(inputs).to(device)
                targets = Variable(targets).to(device)
                optimizer.zero_grad()
                outputs = self.model(inputs)
                loss = criterion(outputs, targets)
                soft_outputs = activation(outputs).data.cpu().numpy()
                numpy_targets = targets.data.cpu().numpy()
                indices = []
                for pair,index in zip(soft_outputs,numpy_targets):
                    indices.append(pair[index])
                train_accuracy += np.sum(indices)
                train_cost += float(loss)
                loss.backward()
                optimizer.step()

            self.accuracy.append(train_accuracy / len(self.data))
            self.costs.append(train_cost / len(self.data))
            print('train cost: %f' % (self.costs[-1]))
            print('train accuracy: %f' % (self.accuracy[-1]))

        with open('record_3.txt','w') as f:
            for cost,ac in zip(self.costs,self.accuracy):
                f.write(str(cost)+','+str(ac)+'\n')
                f.flush()
        f.close()

# Tester for testing
class Tester():
    def __init__(self, model, data):

        self.model = model
        self.data = data

        self.test_loader = torch.utils.data.DataLoader(dataset=self.data, batch_size=32, shuffle=True)

    def test(self, ne):
        criterion = nn.CrossEntropyLoss()
        activation = nn.Softmax()

        self.costs = []
        self.accuracy = []
        for e in range(ne):

            print('testing epoch %d / %d ...' % (e + 1, ne))

            test_cost = 0
            test_accuracy = 0
            for batch_idx, (inputs, targets) in enumerate(self.test_loader):
                inputs = Variable(inputs).to(device)
                targets = Variable(targets).to(device)
                outputs = self.model(inputs)
                loss = criterion(outputs, targets)
                soft_outputs = activation(outputs).data.cpu().numpy()
                numpy_targets = targets.data.cpu().numpy()
                indices = []
                for pair, index in zip(soft_outputs, numpy_targets):
                    indices.append(pair[index])
                test_accuracy += np.sum(indices)
                test_cost += float(loss)

            self.accuracy.append(test_accuracy / len(self.data))
            self.costs.append(test_cost / len(self.data))
            print('test cost: %f' % (self.costs[-1]))
            print('test accuracy: %f' % (self.accuracy[-1]))
        with open('record_test_3.txt','w') as f:
            for cost,ac in zip(self.costs,self.accuracy):
                f.write(str(cost)+','+str(ac)+'\n')
                f.flush()
        f.close()

if __name__ == "__main__":
    # train process
    train_inputs,test_inputs,train_pre,test_pre, vocabulary,lenvocab = load_data('data/senti_binary.train','data/senti_binary.test')
    train_data = list(zip(train_inputs, train_pre))  # train data
    test_data = list(zip(test_inputs, test_pre)) # test data
    # Build model (on GPU)
    device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")
    model = Model(lenvocab, 50, 128, 192, 2)  # 1,0 for output_dim
    model.to(device)
    model.train()
    model.double()
    # Learning (Training)
    trainer = Trainer(model, train_data)
    trainer.train(0.001, 700)  # 1000 epochs

    # Save model
    # torch.save(model.state_dict(), 'part3_state.chkpt')

    # Load Model for test
    # model = Model(lenvocab, 50, 128, 192, 2)
    # model.load_state_dict(torch.load('part3_state.chkpt'))
    # model.to(device)
    # model.eval()
    # model.double()
    # Testing
    tester = Tester(model,test_data)
    tester.test(700) # test for 700 epoch


    # Draw graph of loss
    plt.figure(1)
    plt.plot(range(len(trainer.costs)), trainer.costs, c='r',marker='o', mec='r', mfc='r')
    plt.plot(range(len(tester.costs)), tester.costs, c='b',marker='o', mec='b', mfc='b')
    plt.xlabel('epoch')
    plt.ylabel('loss')
    plt.title('train loss vs test loss')
    plt.savefig("project1_part3_plots_loss.png")
    # Draw graph of accuracy
    plt.figure(2)
    plt.plot(range(len(trainer.accuracy)), trainer.accuracy, c='r',marker='o', mec='r', mfc='r')
    plt.plot(range(len(tester.accuracy)), tester.accuracy, c='b',marker='o', mec='b', mfc='b')
    plt.xlabel('epoch')
    plt.ylabel('accuracy')
    plt.title('train accuracy vs test accuracy')
    plt.savefig("project1_part3_plots_accuracy.png")
