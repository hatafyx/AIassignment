import torch
import torch.utils.data
from torch import nn
from torch.autograd import Variable
import numpy as np
import matplotlib.pyplot as plt
from pylab import rcParams
rcParams['figure.figsize'] = 15, 10

# read pre-trained embeddings from file vw_50d.txt
def read_glove_vecs(glove_file):
    with open(glove_file, 'r') as f:
        words = set()
        word_to_vec_map = {}

        for line in f:
            line = line.strip().split()
            curr_word = line[0]
            words.add(curr_word)
            word_to_vec_map[curr_word] = np.array(line[1:], dtype=np.float64)
    f.close()
    return words, word_to_vec_map


# read data from senti_binary file
def read_data(file, word_to_vec_map, words):
    prediction = []
    inputs = []
    with open(file,'r') as f:
        for line in f:
            line = line.strip().split()
            if line[-1]=='0':
                prediction.append(0)
            else:
                prediction.append(1)
            l = []
            for word in line[:-1]:
                # if the word is in pre-trained embeddings
                if word in words:
                    l.append(word_to_vec_map[word])
                # the word not found in pre-trained embedding will be all-zeros.
                else:
                    l.append(np.zeros((50,), dtype=np.double))
            inputs.append(np.mean(l,axis=0, dtype=np.double))
    f.close()
    return inputs,prediction



class Model(nn.Module):

    def __init__(self, input_dim, hidden1_dim, hidden2_dim, output_dim):
        super(Model, self).__init__()

        self.hl1 = nn.Linear(input_dim, hidden1_dim)
        self.hl1d = nn.Dropout(0.5)
        self.hl1a = nn.ReLU()
        self.layer1 = [self.hl1, self.hl1d, self.hl1a]

        self.hl2 = nn.Linear(hidden1_dim, hidden2_dim)
        self.hl2d = nn.Dropout(0.5)
        self.hl2a = nn.ReLU()
        self.layer2 = [self.hl2, self.hl2d, self.hl2a]

        self.ol = nn.Linear(hidden2_dim, output_dim)

        self.hidden_layers = [self.layer1,self.layer2]

    def forward(self, x):

        out = x
        for pa, d, a in self.hidden_layers:
            out = a(d(pa(out)))
        out = self.ol(out)
        return out

    def predict(self, text, words, word_to_vec_map):
        """
        :param text: a list of words waited to be predicted
        :param words: vocabulary
        :param word_to_vec_map: embeddings from Glove
        :return:
        """
        inputs = []
        activation = nn.Softmax()
        for word in text:
            # if the word is in pre-trained embeddings
            if word in words:
                inputs.append(word_to_vec_map[word])
            # the word not found in pre-trained embedding will be all-zeros.
            else:
                inputs.append(np.zeros((50,), dtype=np.double))
        inputs = np.mean(inputs,axis=0,dtype=np.double)
        output = self.forward(inputs)
        dist = activation(output).data.numpy()
        if dist[0]>=dist[1]:
            return 1
        else:
            return 0

#Trainer for training
class Trainer():
    def __init__(self, model, data):

        self.model = model
        self.data = data

        self.train_loader = torch.utils.data.DataLoader(dataset=self.data, batch_size=32, shuffle=True)

    def train(self, lr, ne):

        criterion = nn.CrossEntropyLoss()
        activation = nn.Softmax()
        optimizer = torch.optim.SGD(self.model.parameters(), lr=lr, momentum=0.9)

        self.model.train()

        self.costs = []
        self.accuracy = []
        for e in range(ne):

            print('training epoch %d / %d ...' % (e + 1, ne))

            train_cost = 0
            train_accuracy = 0
            for batch_idx, (inputs, targets) in enumerate(self.train_loader):
                inputs = Variable(inputs).to(device)
                targets = Variable(targets).to(device)
                optimizer.zero_grad()
                outputs = self.model(inputs)
                loss = criterion(outputs, targets)
                soft_outputs = activation(outputs).data.cpu().numpy()
                numpy_targets = targets.data.cpu().numpy()
                indices = []
                for pair,index in zip(soft_outputs,numpy_targets):
                    indices.append(pair[index])
                train_accuracy += np.sum(indices)
                train_cost += float(loss) # avoid out of memory because 'cost' is a differential tensor
                loss.backward()
                optimizer.step()

            self.accuracy.append(train_accuracy / len(self.data))
            self.costs.append(train_cost / len(self.data))
            print('train cost: %f' % (self.costs[-1]))
            print('train accuracy: %f' % (self.accuracy[-1]))
        with open('record_1.txt','w') as f:
            for cost,ac in zip(self.costs,self.accuracy):
                f.write(str(cost)+','+str(ac)+'\n')
                f.flush()
        f.close()


# Tester for testing
class Tester():
    def __init__(self, model, data):

        self.model = model
        self.data = data

        self.test_loader = torch.utils.data.DataLoader(dataset=self.data, batch_size=32, shuffle=True)

    def test(self, ne):
        criterion = nn.CrossEntropyLoss()
        activation = nn.Softmax()

        self.costs = []
        self.accuracy = []
        for e in range(ne):

            print('testing epoch %d / %d ...' % (e + 1, ne))

            test_cost = 0
            test_accuracy = 0
            for batch_idx, (inputs, targets) in enumerate(self.test_loader):
                inputs = Variable(inputs).to(device)
                targets = Variable(targets).to(device)
                outputs = self.model(inputs)
                loss = criterion(outputs, targets)
                soft_outputs = activation(outputs).data.cpu().numpy()
                numpy_targets = targets.data.cpu().numpy()
                indices = []
                for pair, index in zip(soft_outputs, numpy_targets):
                    indices.append(pair[index])
                test_accuracy += np.sum(indices)
                test_cost += float(loss)

            self.accuracy.append(test_accuracy / len(self.data))
            self.costs.append(test_cost / len(self.data))
            print('test cost: %f' % (self.costs[-1]))
            print('test accuracy: %f' % (self.accuracy[-1]))
        with open('record_test_1.txt','w') as f:
            for cost,ac in zip(self.costs,self.accuracy):
                f.write(str(cost)+','+str(ac)+'\n')
                f.flush()
        f.close()

if __name__ == "__main__":
    words, word_to_vec_map = read_glove_vecs('data/wv_50d.txt/wv_50d.txt')
    # train process
    train_inputs, train_pre = read_data('data/senti_binary.train', word_to_vec_map, words)
    train_data = list(zip(train_inputs, train_pre))  # train data
    # Build model
    device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")
    model = Model(50, 128, 192, 2)  # 1,0 for output_dim
    model.to(device)
    model.double()
    # Learning (Training)
    trainer = Trainer(model, train_data)
    trainer.train(0.001, 700)  # 600 epochs

    # Save model
    torch.save(model.state_dict(), 'part1_state.chkpt')

    test_inputs, test_pre = read_data('data/senti_binary.test', word_to_vec_map, words)
    test_data = list(zip(test_inputs, test_pre))  # test_data
    # Load Model for test
    # model = Model(50,128, 192, 2)
    # model.load_state_dict(torch.load('part1_state.chkpt'))
    # model.eval()
    # model.to(device)
    # model.double()
    # Testing
    tester = Tester(model,test_data)
    tester.test(700) # test for 600 epoch


    # Draw graph of loss
    plt.figure(1)
    plt.plot(range(len(trainer.costs)), trainer.costs,c='r',marker='o', mec='r', mfc='r')
    plt.plot(range(len(tester.costs)), tester.costs,c='b',marker='o', mec='b', mfc='b')
    plt.xlabel('epoch')
    plt.ylabel('loss')
    plt.title('train loss vs test loss')
    plt.savefig("project1_part1_plots_loss.png")
    # Draw graph of accuracy
    plt.figure(2)
    plt.plot(range(len(trainer.accuracy)), trainer.accuracy,c='r',marker='o', mec='r', mfc='r')
    plt.plot(range(len(tester.accuracy)), tester.accuracy,c='b',marker='o', mec='b', mfc='b')
    plt.xlabel('epoch')
    plt.ylabel('accuracy')
    plt.title('train accuracy vs test accuracy')
    plt.savefig("project1_part1_plots_accuracy.png")
